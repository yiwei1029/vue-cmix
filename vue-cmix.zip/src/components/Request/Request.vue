<template>
    <section class="Request">
        <el-row :gutter="10">
            <!-- 左边 -->
            <el-col :span="12">
                <!-- input -->

                <el-card>
                    <el-row><span>Input</span></el-row>
                    <el-row v-for="input  in InputList" :gutter="20">
                        <el-col :span="15">
                            <!-- <div>{{ input.hash }}</div> -->
                            <el-popover placement="top-start" trigger="hover" :content="input.hash">
                                <el-button slot="reference" type="text">{{ input.hash.substring(0, 40) + "..."
                                }}</el-button>
                            </el-popover>
                        </el-col>
                        <el-col :span="6">
                            <el-popover disabled>
                                <el-button slot="reference" type="text">{{ input.amount }}</el-button>
                            </el-popover>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="15">
                            <el-button style="width: 100%;">+</el-button>
                        </el-col>
                    </el-row>
                </el-card>
                <!-- output -->
                <el-card>
                    <el-row><span>Output</span></el-row>
                    <el-row v-for="output  in OutputList" :gutter="20">
                        <el-col :span="15">
                            <el-popover placement="top-start" trigger="hover" :content="output.hash">
                                <el-button slot="reference" type="text">{{ output.hash.substring(0, 40) + "..."
                                }}</el-button>
                            </el-popover>
                        </el-col>
                        <el-col :span="6">
                            <el-popover disabled>
                                <el-button slot="reference" type="text">{{ output.amount }}</el-button>
                            </el-popover>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="15">
                            <el-button style="width: 100%;">+</el-button>
                        </el-col>
                    </el-row>
                </el-card>
            </el-col>
            <!-- 右边 -->
            <el-col :span="10">
                <el-card>
                    <div class="left-right">
                        Select A Coordination
                    </div>
                    <!-- form to sumbit c -->
                    <div>
                        <el-form :model="Form" style="display: flex; align-items: start;">
                            <el-form-item>
                                <el-input placeholder="Please input c" v-model="Form.valueOfC"></el-input>
                            </el-form-item>
                            <el-button type="primary" @click="sendRequest">Send Request</el-button>
                        </el-form>
                    </div>
                    <div class="number-display" v-if="NumberDisplay">
                        <div>#Input: {{ 1 }}</div>
                        <div>#Output: {{ 1 }}</div>
                        <div>Fee: {{ 0.01 }}</div>
                    </div>

                    <el-button type="primary" style="width: 100%;">Send Transaction</el-button>
                </el-card>
            </el-col>
        </el-row>
    </section>
</template>

<script>
export default {
    name: 'Request',
    data() {
        return {
            InputList: [
                { hash: 'bc1quqfl65xqtkprhrygpdpeg4r7q20zyaq8xvxd3a', amount: 0.00571223 },
                { hash: 'bc1qnalwjznls42dzvaw4m5u48td032692aslqwg9m', amount: 0.00127342 },
                { hash: 'bc1q5t94hycpjv2uegcchfr7q30tsuhq8wd2u90cg4', amount: 0.00349666 },
                { hash: 'bc1qm4ztr7257hlqk3x670zr6maz36qnehczuetqrn', amount: 0.00428200 }

            ],
            OutputList: [
                { hash: 'bc1quqfl65xqtkprhrygpdpeg4r7q20zyaq8xvxd3a', amount: 0.00571223 },
                { hash: 'bc1qnalwjznls42dzvaw4m5u48td032692aslqwg9m', amount: 0.00127342 },
                { hash: 'bc1q5t94hycpjv2uegcchfr7q30tsuhq8wd2u90cg4', amount: 0.00349666 },
                { hash: 'bc1qm4ztr7257hlqk3x670zr6maz36qnehczuetqrn', amount: 0.00428200 }

            ],
            show: true,
            NumberDisplay: false,
            Form: {
                valueOfC: ''
            }
        }
    },
    components: {},
    watch: {},
    mounted() { },
    methods: {
        sendRequest() {
            this.NumberDisplay = true
        }
    }
}
</script>

<style scoped lang="less">
.el-col {
    overflow: hidden;
    text-overflow: ellipsis;
}

.el-card {
    margin-bottom: 20px;
}

.left-right {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    align-items: center;

    :first-child {
        box-sizing: border-box;

    }

    :last-child {
        box-sizing: border-box;
    }
}

.el-input {
    // width: 50%;
}

.number-display {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;

    >div {
        background-color: #8977fd;
        color: #fff;
        padding: 4px 6px;
        border-radius: 6px;

    }
}
</style>

