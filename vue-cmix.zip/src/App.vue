<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
import router from './router';


export default {
  name: 'app',
  components: { router }
}
</script>

<style></style>
